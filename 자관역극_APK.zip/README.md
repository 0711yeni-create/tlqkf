# 자관 역극 (JaRoleplay)

아이폰 메시지 느낌의 1인용 자캐/자관 역극 Android 앱 프로토타입입니다.

## 포함 기능
- 캐릭터 A/B 이름 설정
- 캐릭터별 말풍선 색상
- A/B 전환 버튼
- 메시지 입력 및 전송
- 대화 초기화
- 메모리상 대화 유지

## APK 만들기
1. Android Studio 설치
2. 이 ZIP을 압축 해제
3. Android Studio에서 폴더 열기
4. Gradle Sync 완료
5. Build > Build APK(s)
6. `app/build/outputs/apk/debug/app-debug.apk` 확인

인터넷 연결이 필요한 첫 Gradle 동기화에서는 Android Gradle Plugin/Kotlin 플러그인을 내려받을 수 있습니다.
