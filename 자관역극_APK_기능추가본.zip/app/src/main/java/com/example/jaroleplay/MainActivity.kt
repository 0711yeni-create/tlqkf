package com.example.jaroleplay

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

private data class CharacterData(
    var id: String,
    var name: String,
    var imageUri: String = ""
)

private data class MessageData(
    var id: String,
    var senderId: String,
    var text: String
)

private data class ChatRoomData(
    var id: String,
    var name: String,
    val characters: MutableList<CharacterData> = mutableListOf(),
    val messages: MutableList<MessageData> = mutableListOf()
)

private data class FolderData(
    var id: String,
    var name: String,
    val rooms: MutableList<ChatRoomData> = mutableListOf()
)

class MainActivity : Activity() {
    private val prefs: SharedPreferences by lazy {
        getSharedPreferences("jaroleplay_data", Context.MODE_PRIVATE)
    }

    private val folders = mutableListOf<FolderData>()
    private var currentFolderId: String? = null
    private var currentRoomId: String? = null
    private var activeCharacterId: String? = null
    private var pendingCharacterId: String? = null

    private val blue = Color.rgb(0, 122, 255)
    private val bg = Color.rgb(242, 242, 247)
    private val border = Color.rgb(220, 220, 225)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadData()
        showFolders()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun tv(text: String, size: Float, color: Int = Color.BLACK): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
        }

    private fun button(text: String, size: Float = 15f): Button =
        Button(this).apply {
            this.text = text
            textSize = size
            setTextColor(blue)
            setBackgroundColor(Color.TRANSPARENT)
            isAllCaps = false
            minHeight = 0
            minWidth = 0
            stateListAnimator = null
        }

    private fun rounded(color: Int, radius: Float, strokeColor: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            if (strokeColor != null) setStroke(dp(1), strokeColor)
        }

    private fun page(title: String, backAction: (() -> Unit)? = null, addAction: (() -> Unit)? = null): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(5), dp(8), dp(5))
            setBackgroundColor(Color.WHITE)
        }
        if (backAction != null) {
            val back = button("‹", 34f)
            back.setOnClickListener { backAction() }
            header.addView(back, LinearLayout.LayoutParams(dp(48), dp(52)))
        } else {
            header.addView(Space(this), LinearLayout.LayoutParams(dp(10), dp(1)))
        }
        val titleView = tv(title, 19f)
        titleView.gravity = Gravity.CENTER
        titleView.setTypeface(null, Typeface.BOLD)
        header.addView(titleView, LinearLayout.LayoutParams(0, dp(52), 1f))
        if (addAction != null) {
            val add = button("＋", 27f)
            add.setOnClickListener { addAction() }
            header.addView(add, LinearLayout.LayoutParams(dp(48), dp(52)))
        } else {
            header.addView(Space(this), LinearLayout.LayoutParams(dp(48), dp(1)))
        }
        root.addView(header)
        return root
    }

    private fun showFolders() {
        val root = page("자관", addAction = { newFolderDialog() })
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(14), dp(12), dp(24))
        }
        if (folders.isEmpty()) {
            list.addView(emptyView("아직 자관 폴더가 없어요.\n오른쪽 위 ＋를 눌러 만들어보세요."))
        } else {
            folders.forEach { folder ->
                val row = cardRow()
                val icon = avatarView("📁", "", 54)
                row.addView(icon, LinearLayout.LayoutParams(dp(54), dp(54)))
                val texts = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(14), 0, dp(8), 0)
                }
                val title = tv(folder.name, 17f)
                title.setTypeface(null, Typeface.BOLD)
                texts.addView(title)
                texts.addView(tv("대화방 ${folder.rooms.size}개", 13f, Color.GRAY))
                row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(tv("›", 30f, Color.GRAY).apply { gravity = Gravity.CENTER_VERTICAL })
                row.setOnClickListener {
                    currentFolderId = folder.id
                    showRooms(folder)
                }
                row.setOnLongClickListener {
                    confirmDeleteFolder(folder)
                    true
                }
                list.addView(row)
            }
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showRooms(folder: FolderData) {
        val root = page(folder.name, backAction = { showFolders() }, addAction = { newRoomDialog(folder) })
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(14), dp(12), dp(24))
        }
        if (folder.rooms.isEmpty()) {
            list.addView(emptyView("이 폴더에는 대화방이 없어요.\n오른쪽 위 ＋로 대화방을 만들어보세요."))
        } else {
            folder.rooms.forEach { room ->
                val row = cardRow()
                val first = room.characters.firstOrNull()?.name?.firstOrNull()?.toString() ?: "💬"
                row.addView(avatarView(first, room.characters.firstOrNull()?.imageUri ?: "", 54), LinearLayout.LayoutParams(dp(54), dp(54)))
                val texts = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(14), 0, dp(8), 0)
                }
                val title = tv(room.name, 17f)
                title.setTypeface(null, Typeface.BOLD)
                texts.addView(title)
                val names = room.characters.joinToString(", ") { it.name }.ifEmpty { "캐릭터 없음" }
                texts.addView(tv(names, 13f, Color.GRAY), LinearLayout.LayoutParams(-1, -2))
                row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(tv("›", 30f, Color.GRAY).apply { gravity = Gravity.CENTER_VERTICAL })
                row.setOnClickListener {
                    currentFolderId = folder.id
                    currentRoomId = room.id
                    activeCharacterId = room.characters.firstOrNull()?.id
                    showChat(folder, room)
                }
                row.setOnLongClickListener {
                    confirmDeleteRoom(folder, room)
                    true
                }
                list.addView(row)
            }
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showChat(folder: FolderData, room: ChatRoomData) {
        if (room.characters.isEmpty()) {
            room.characters.add(CharacterData(newId(), "캐릭터 A"))
            activeCharacterId = room.characters.first().id
            saveData()
        }
        if (activeCharacterId == null || room.characters.none { it.id == activeCharacterId }) {
            activeCharacterId = room.characters.first().id
        }

        val root = page(room.name, backAction = { showRooms(folder) }, addAction = { showCharacters(folder, room) })
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
            setBackgroundColor(Color.WHITE)
        }
        info.addView(tv("현재 역할", 12f, Color.GRAY))
        val roleName = tv(activeCharacter(room)?.name ?: "캐릭터", 15f)
        roleName.setTypeface(null, Typeface.BOLD)
        info.addView(roleName, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(8) })
        val manage = button("캐릭터", 13f)
        manage.setOnClickListener { showCharacters(folder, room) }
        info.addView(manage, LinearLayout.LayoutParams(dp(80), dp(42)))
        root.addView(info)

        val chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(12), dp(10), dp(12))
        }
        val scroll = ScrollView(this).apply {
            addView(chat)
        }
        renderMessages(chat, room)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(7), dp(8), dp(7))
            setBackgroundColor(Color.WHITE)
        }
        val active = button((activeCharacter(room)?.name ?: "역할") + " ▾", 13f)
        active.setTextColor(Color.DKGRAY)
        active.background = rounded(Color.rgb(242, 242, 247), dp(18).toFloat())
        active.setOnClickListener {
            showRoleChooser(folder, room)
        }
        bar.addView(active, LinearLayout.LayoutParams(dp(100), dp(48)))

        val input = EditText(this).apply {
            hint = "iMessage"
            textSize = 16f
            maxLines = 3
            setPadding(dp(14), 0, dp(14), 0)
            background = rounded(Color.rgb(242, 242, 247), dp(21).toFloat())
        }
        bar.addView(input, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
            setMargins(dp(7), 0, dp(7), 0)
        })
        val send = button("↑", 22f)
        send.setTextColor(Color.WHITE)
        send.background = rounded(blue, dp(24).toFloat())
        send.setOnClickListener {
            val text = input.text.toString().trim()
            val sender = activeCharacter(room) ?: return@setOnClickListener
            if (text.isNotEmpty()) {
                room.messages.add(MessageData(newId(), sender.id, text))
                saveData()
                input.text.clear()
                renderMessages(chat, room)
                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            }
        }
        bar.addView(send, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(bar)
        setContentView(root)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun renderMessages(chat: LinearLayout, room: ChatRoomData) {
        chat.removeAllViews()
        val activeId = activeCharacterId
        if (room.messages.isEmpty()) {
            chat.addView(emptyView("대화를 시작해보세요."))
            return
        }
        room.messages.forEach { message ->
            val sender = room.characters.firstOrNull { it.id == message.senderId } ?: return@forEach
            val mine = sender.id == activeId
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = if (mine) Gravity.END else Gravity.START
                setPadding(dp(4), dp(3), dp(4), dp(3))
            }
            if (!mine) {
                line.addView(avatarView(sender.name.firstOrNull()?.toString() ?: "?", sender.imageUri, 36), LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(7) })
            }
            val column = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = if (mine) Gravity.END else Gravity.START
            }
            val senderName = tv(sender.name, 11f, Color.GRAY)
            senderName.setPadding(dp(5), 0, dp(5), dp(3))
            column.addView(senderName)
            val bubble = TextView(this).apply {
                text = message.text
                textSize = 16f
                setTextColor(if (mine) Color.WHITE else Color.BLACK)
                setPadding(dp(14), dp(10), dp(14), dp(10))
                background = rounded(if (mine) blue else Color.WHITE, dp(19).toFloat(), if (mine) null else border)
                maxWidth = dp(285)
            }
            column.addView(bubble, LinearLayout.LayoutParams(-2, -2))
            line.addView(column)
            chat.addView(line)
        }
    }

    private fun showCharacters(folder: FolderData, room: ChatRoomData) {
        val root = page("캐릭터", backAction = { showChat(folder, room) }, addAction = { addCharacterDialog(folder, room) })
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(14), dp(12), dp(24))
        }
        room.characters.forEach { character ->
            val row = cardRow()
            row.addView(avatarView(character.name.firstOrNull()?.toString() ?: "?", character.imageUri, 58), LinearLayout.LayoutParams(dp(58), dp(58)))
            val texts = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), 0, dp(8), 0)
            }
            val name = tv(character.name, 17f)
            name.setTypeface(null, Typeface.BOLD)
            texts.addView(name)
            texts.addView(tv(if (character.id == activeCharacterId) "현재 역할" else "탭해서 역할 전환", 12f, if (character.id == activeCharacterId) blue else Color.GRAY))
            row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
            val photo = button("사진", 13f)
            photo.setOnClickListener {
                pendingCharacterId = character.id
                pickImage()
            }
            row.addView(photo, LinearLayout.LayoutParams(dp(62), dp(48)))
            row.setOnClickListener {
                activeCharacterId = character.id
                saveData()
                showCharacters(folder, room)
            }
            row.setOnLongClickListener {
                confirmDeleteCharacter(folder, room, character)
                true
            }
            list.addView(row)
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showRoleChooser(folder: FolderData, room: ChatRoomData) {
        val names = room.characters.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("어느 캐릭터의 화면으로 볼까요?")
            .setItems(names) { _, which ->
                activeCharacterId = room.characters[which].id
                saveData()
                showChat(folder, room)
            }
            .show()
    }

    private fun avatarView(initial: String, imageUri: String, size: Int): View {
        if (imageUri.isNotEmpty()) {
            val image = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageURI(Uri.parse(imageUri))
                background = rounded(Color.WHITE, dp(size / 2).toFloat())
                clipToOutline = true
            }
            return image
        }
        return TextView(this).apply {
            text = initial.take(1)
            textSize = if (size <= 40) 15f else 20f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(225, 225, 230), dp(size / 2).toFloat())
        }
    }

    private fun cardRow(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(12), dp(10), dp(10), dp(10))
        background = rounded(Color.WHITE, dp(17).toFloat())
        isClickable = true
        val lp = LinearLayout.LayoutParams(-1, dp(78))
        lp.bottomMargin = dp(9)
        layoutParams = lp
    }

    private fun emptyView(text: String): TextView = tv(text, 15f, Color.GRAY).apply {
        gravity = Gravity.CENTER
        setPadding(dp(25), dp(55), dp(25), dp(55))
    }

    private fun newFolderDialog() {
        val input = EditText(this).apply { hint = "자관 이름" }
        AlertDialog.Builder(this)
            .setTitle("새 자관 폴더")
            .setView(input)
            .setNegativeButton("취소", null)
            .setPositiveButton("만들기") { _, _ ->
                val name = input.text.toString().trim().ifEmpty { "새 자관" }
                folders.add(FolderData(newId(), name))
                saveData()
                showFolders()
            }.show()
    }

    private fun newRoomDialog(folder: FolderData) {
        val input = EditText(this).apply { hint = "대화방 이름" }
        AlertDialog.Builder(this)
            .setTitle("새 대화방")
            .setView(input)
            .setNegativeButton("취소", null)
            .setPositiveButton("만들기") { _, _ ->
                val room = ChatRoomData(newId(), input.text.toString().trim().ifEmpty { "새 대화방" })
                room.characters.add(CharacterData(newId(), "캐릭터 A"))
                room.characters.add(CharacterData(newId(), "캐릭터 B"))
                folder.rooms.add(room)
                saveData()
                showRooms(folder)
            }.show()
    }

    private fun addCharacterDialog(folder: FolderData, room: ChatRoomData) {
        val input = EditText(this).apply { hint = "캐릭터 이름" }
        AlertDialog.Builder(this)
            .setTitle("캐릭터 추가")
            .setView(input)
            .setNegativeButton("취소", null)
            .setPositiveButton("추가") { _, _ ->
                val name = input.text.toString().trim().ifEmpty { "새 캐릭터" }
                room.characters.add(CharacterData(newId(), name))
                saveData()
                showCharacters(folder, room)
            }.show()
    }

    private fun pickImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, 1001)
    }

    @Deprecated("Deprecated in Android API, kept for API 24 compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 1001 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) { }
        val folder = folders.firstOrNull { it.id == currentFolderId } ?: return
        val room = folder.rooms.firstOrNull { it.id == currentRoomId } ?: return
        val character = room.characters.firstOrNull { it.id == pendingCharacterId } ?: return
        character.imageUri = uri.toString()
        pendingCharacterId = null
        saveData()
        showCharacters(folder, room)
    }

    private fun confirmDeleteFolder(folder: FolderData) {
        AlertDialog.Builder(this)
            .setTitle("폴더 삭제")
            .setMessage("'${folder.name}' 안의 대화방도 모두 삭제됩니다.")
            .setNegativeButton("취소", null)
            .setPositiveButton("삭제") { _, _ ->
                folders.removeAll { it.id == folder.id }
                saveData()
                showFolders()
            }.show()
    }

    private fun confirmDeleteRoom(folder: FolderData, room: ChatRoomData) {
        AlertDialog.Builder(this)
            .setTitle("대화방 삭제")
            .setMessage("'${room.name}'을 삭제할까요?")
            .setNegativeButton("취소", null)
            .setPositiveButton("삭제") { _, _ ->
                folder.rooms.removeAll { it.id == room.id }
                saveData()
                showRooms(folder)
            }.show()
    }

    private fun confirmDeleteCharacter(folder: FolderData, room: ChatRoomData, character: CharacterData) {
        if (room.characters.size <= 1) return
        AlertDialog.Builder(this)
            .setTitle("캐릭터 삭제")
            .setMessage("'${character.name}'을 삭제할까요?\n기존 메시지는 남지만 보낸 사람 이름이 표시되지 않을 수 있어요.")
            .setNegativeButton("취소", null)
            .setPositiveButton("삭제") { _, _ ->
                room.characters.removeAll { it.id == character.id }
                if (activeCharacterId == character.id) activeCharacterId = room.characters.firstOrNull()?.id
                saveData()
                showCharacters(folder, room)
            }.show()
    }

    private fun activeCharacter(room: ChatRoomData): CharacterData? =
        room.characters.firstOrNull { it.id == activeCharacterId }

    private fun newId(): String = System.currentTimeMillis().toString() + "_" + (0..99999).random()

    private fun saveData() {
        val root = JSONArray()
        folders.forEach { folder ->
            val f = JSONObject().put("id", folder.id).put("name", folder.name)
            val rooms = JSONArray()
            folder.rooms.forEach { room ->
                val r = JSONObject().put("id", room.id).put("name", room.name)
                val chars = JSONArray()
                room.characters.forEach { c ->
                    chars.put(JSONObject().put("id", c.id).put("name", c.name).put("imageUri", c.imageUri))
                }
                val messages = JSONArray()
                room.messages.forEach { m ->
                    messages.put(JSONObject().put("id", m.id).put("senderId", m.senderId).put("text", m.text))
                }
                r.put("characters", chars).put("messages", messages)
                rooms.put(r)
            }
            f.put("rooms", rooms)
            root.put(f)
        }
        prefs.edit().putString("folders", root.toString()).apply()
    }

    private fun loadData() {
        folders.clear()
        val raw = prefs.getString("folders", null) ?: return
        try {
            val root = JSONArray(raw)
            for (i in 0 until root.length()) {
                val f = root.getJSONObject(i)
                val folder = FolderData(f.getString("id"), f.getString("name"))
                val rooms = f.optJSONArray("rooms") ?: JSONArray()
                for (j in 0 until rooms.length()) {
                    val r = rooms.getJSONObject(j)
                    val room = ChatRoomData(r.getString("id"), r.getString("name"))
                    val chars = r.optJSONArray("characters") ?: JSONArray()
                    for (k in 0 until chars.length()) {
                        val c = chars.getJSONObject(k)
                        room.characters.add(CharacterData(c.getString("id"), c.getString("name"), c.optString("imageUri", "")))
                    }
                    val messages = r.optJSONArray("messages") ?: JSONArray()
                    for (k in 0 until messages.length()) {
                        val m = messages.getJSONObject(k)
                        room.messages.add(MessageData(m.getString("id"), m.getString("senderId"), m.getString("text")))
                    }
                    folder.rooms.add(room)
                }
                folders.add(folder)
            }
        } catch (_: Exception) {
            folders.clear()
        }
    }
}
